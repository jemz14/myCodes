
var w = 900;
var h = 600;
var platform,bg,crystal,ghost,platforms,scoreText,gameOverText,ghosts,crystals,bestText;
var platform,bg,crystal,ghost,platforms,scoreText,gameOverText,ghosts,crystals;
var player;
var platforms;
var cursors;

var basicGame;
var stars , star;
var anons;
var score = 0;
var scoreText;
var demonyos;
var bestScoreText;
var bgAudio1 , bgAudio2 , bgAudio3;
var soundeffects;
var btn;
var start;
var bullets;
   var left=false;
        var right=false;
var bulletTime = 0;
var cursors;
var fireButton;
var firingTimer = 0;
var bg1, bg2, bg3;
var audio, audio1, audio2, effect;
var text;
var aswang, multo, aswang2, aswang3, aswang4, aswang5, aswang6, aswang7, aswang8, aswang9, aswang10;
var multo2, multos2, multo3, multos3, multo4, multos4, multo5, multos5, multo6, multos6, multo7, multos7, multo8, multos8, multo9, multos9, multo10, multos10;
var star1, stars1, star2, stars2, star3, stars3, star4, stars4, star5, stars5, star6, stars6, star7, stars7, star8, stars8, star9, stars9, star10, stars10;
game = new Phaser.Game(w, h, Phaser.CANVAS, '');

game.state.add('Menu', Menu);


game.state.start('Menu');

game.state.add('Level1');
game.state.add('Level2');
game.state.add('Level3');
game.state.add('Level4');
game.state.add('Level5');
game.state.add('Level6');
game.state.add('Level7');
game.state.add('Level8');
game.state.add('Level9');
game.state.add('Level10');
game.state.add('Gameover');
game.state.add('Gameover2');
game.state.add('Gameover3');
game.state.add('Gameover3');
game.state.add('Gameover4');
game.state.add('Gameover5');
game.state.add('Gameover6');
game.state.add('Gameover7');
game.state.add('Gameover8');
game.state.add('Gameover9');
game.state.add('Gameover10');
game.state.add('Congrats');
