var bounds = 900;
var text;
var Level8 = {
 preload: function() {
 
            game.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL;
            game.scale.pageAlignHorizontally = true;
            game.scale.pageAlignVertically = true;
            game.stage.backgroundColor = 'blue'; 
              game.load.image("wall", 'assets/wall.jpeg');
      game.load.image("sky8", 'assets/bg8.jpg');
            game.load.image("bird", 'assets/bird1.png');
              game.load.image("level3", 'assets/lvl8.png');
                game.load.image("multo", 'assets/hello.png');
                    game.load.image("restart", 'assets/restart.png');
            game.load.image("2", 'assets/door.png',process.start7);
          
           game.load.spritesheet("tao", 'assets/boy.png',112,117);
      
      
         
                     game.load.audio("scream","music/scream.mp3");
               game.load.audio("soundeffects","music/soundeffects.wav");
                     game.load.image("left", 'assets/left.png');
                                         game.load.image("right", 'assets/right.png');
                                                   game.load.image("jump", 'assets/jump.png');

},
 create: function() {

            game.physics.startSystem(Phaser.Physics.ARCADE);
            game.world.setBounds(0,0,1200,0);
     
                  game.add.sprite(0, 0, 'sky8');

            platforms = game.add.group();
            platforms.enableBody = true;
            jemz = game.add.group();
            jemz.enableBody = true;
                game.input.onDown.add(process.unpause, self);
            btn = game.add.button(10,50,"pause",process.pause);
            btn.fixedToCamera=true;
               btn = game.add.button(530,10,"restart",process.restart8);
            btn.fixedToCamera=true;
            soundeffects = game.add.audio("soundeffects");  
          
                 text = game.add.image(750,10, "level3");
            text.fixedToCamera = true;
         process.createMultos8(4000);
            multo8 = game.add.group();
            multo8.enableBody = true;
              level = game.add.group();
            level.enableBody = true;

 

             var ledge = level.create(1000,490,"2", process.start7);
            ledge.immovable=true;


                  var ground = platforms.create(0, game.world.height - 50, 'wall');
             ground.body.immovable=true;
          
       
            player = game.add.sprite(0, game.world.height - 400, 'tao');

      
            game.physics.arcade.enable(player);


    
            player.body.bounce.y = 0.2;
            player.body.gravity.y = 300;
            player.body.collideWorldBounds = true;

   
             player.animations.add('left', [8, 9, 10, 11],10, true); 
            player.animations.add('right', [4, 5, 6, 7],10, true); 

        
    

            scoreText = game.add.text(16, 16, 'Missing Bird Collected: ', { fontSize: '32px', fill: 'yellow' });
                pauseText = game.add.text(300, 350, '', { fontSize: '500px', fill: 'white' });
           pauseText.fixedToCamera = true;
           
            messageText = game.add.text(180, 180, '', { fontSize: '120px', fill: 'red' });
             game.camera.follow(player, Phaser.Camera.FOLLOW_TOPDOWN);
           niceText = game.add.text(300,350, '', { fontSize: '500px', fill: 'yellow' });
           niceText.fixedToCamera = true;
             scoreText.fixedToCamera = true;
              messageText.fixedToCamera = true;
                game.camera.follow(player, Phaser.Camera.FOLLOW_LOCKON);


        
            cursors = game.input.keyboard.createCursorKeys();
                    stars8 = game.add.group();
            stars8.enableBody = true;
            var star8 = stars8.create(500, 490, 'bird');
             var star8 = stars8.create(700, 490, 'bird');
                     var star8 = stars8.create(200, 490, 'bird');
                     
              buttonleft = game.add.button(46, 500, 'left');
                buttonleft.anchor.setTo(0.5, 0.5);
                buttonleft.fixedToCamera = true;
                buttonleft.events.onInputOver.add(function(){left=true;});
                buttonleft.events.onInputOut.add(function(){left=false;});
                buttonleft.events.onInputDown.add(function(){left=true;});
                buttonleft.events.onInputUp.add(function(){left=false;});
              
             buttonright = game.add.button(200, 500, 'right');
                buttonright.anchor.setTo(0.5, 0.5);
                buttonright.fixedToCamera = true;
                buttonright.events.onInputOver.add(function(){right=true;});
                buttonright.events.onInputOut.add(function(){right=false;});
                buttonright.events.onInputDown.add(function(){right=true;});
                buttonright.events.onInputUp.add(function(){right=false;});
               btn = game.add.button(800,460,"jump",process.jump);
                  btn.fixedToCamera=true;
            
            
        },

update: function() {

 game.physics.arcade.collide(player, platforms);  

  game.physics.arcade.overlap(player, stars8, process.collectStar8, null, this);
 game.physics.arcade.overlap(player, multo8, process.killPlayer8, null, this);
      game.physics.arcade.overlap(player, level, process.start7, null, this);


      

 
if (left) {
               
                player.body.velocity.x=-120;
                player.animations.play('left');
            }
            else if (right) {
          
                player.body.velocity.x=120;
                player.animations.play('right');
            } 
            else {
                   player.body.velocity.x=0;

              player.frame = 1;
            }

            if (game.input.currentPointers == 0 && !game.input.activePointer.isMouse){ fire=false; right=false; left=false; duck=false; jump=false;} //this 
        }
}
game.state.add("Level8" ,Level8, false);