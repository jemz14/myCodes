var bounds = 2000;
var niceText;
var text;
var aswang, multo;
var effect;

var Level1 = {
 preload: function() {
 
            game.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL;
            game.scale.pageAlignHorizontally = true;
            game.scale.pageAlignVertically = true;
            game.stage.backgroundColor = 'blue'; 
               game.load.image("wall", 'assets/wall.jpeg');
   
            game.load.image("bird", 'assets/bird1.png');
                game.load.image("level1", 'assets/level1.png');
                          game.load.image("sky", 'assets/bg1.png');
                game.load.image("restart", 'assets/restart.png');
                     game.load.image("pause", 'assets/pause.png');
                game.load.image("multo", 'assets/aswang.png');
                game.load.image("2", 'assets/door.png',process.start);
            game.load.spritesheet("tao", 'assets/boy.png',112,117);
      
            game.load.audio("bgMusic","music/outlast.mp3");
               game.load.audio("soundeffects","music/soundeffects.wav");
                     game.load.audio("scream","music/scream.mp3");

                               game.load.image("left", 'assets/left.png');
                                         game.load.image("right", 'assets/right.png');
                                                   game.load.image("jump", 'assets/jump.png');

},
 create: function() {


            game.physics.startSystem(Phaser.Physics.ARCADE);
            
      

       game.world.setBounds(0,0,1200,0);
           
                  game.add.sprite(0, 0, 'sky');


            platforms = game.add.group();
            platforms.enableBody = true;
            process.createMultos(10000);
            multo = game.add.group();
            multo.enableBody = true;

     


          
             var ground = platforms.create(0, game.world.height - 50, 'wall');
             ground.body.immovable=true;

            level = game.add.group();
            level.enableBody = true;

            btn = game.add.button(530,10,"restart",process.restart);
            btn.fixedToCamera=true;
            
            game.input.onDown.add(process.unpause, self);
            btn = game.add.button(10,50,"pause",process.pause);
            btn.fixedToCamera=true;

                 
                buttonleft = game.add.button(46, 500, 'left');
                buttonleft.anchor.setTo(0.5, 0.5);
                buttonleft.fixedToCamera = true;
                buttonleft.events.onInputOver.add(function(){left=true;});
                buttonleft.events.onInputOut.add(function(){left=false;});
                buttonleft.events.onInputDown.add(function(){left=true;});
                buttonleft.events.onInputUp.add(function(){left=false;});
              
             buttonright = game.add.button(200, 500, 'right');
                buttonright.anchor.setTo(0.5, 0.5);
                buttonright.fixedToCamera = true;
                buttonright.events.onInputOver.add(function(){right=true;});
                buttonright.events.onInputOut.add(function(){right=false;});
                buttonright.events.onInputDown.add(function(){right=true;});
                buttonright.events.onInputUp.add(function(){right=false;});
               btn = game.add.button(800,460,"jump",process.jump);
                  btn.fixedToCamera=true;
            
            jemz = game.add.group();
            jemz.enableBody = true;
            bgAudio = game.add.audio("bgMusic");
            bgAudio.play();
            process.audio(123800);

            soundeffects = game.add.audio("soundeffects");  
            effect = game.add.audio("scream");
      

            

               var ledge = level.create(1000,490,"2", process.start);
            ledge.immovable=true;


     

            text = game.add.image(750,10, "level1");
            text.fixedToCamera = true;
      
            player = game.add.sprite(0, game.world.height -400, 'tao');

          
            game.physics.arcade.enable(player);


           
            player.body.bounce.y = 0.2;
            player.body.gravity.y = 300;
            player.body.collideWorldBounds = true;

   
            player.animations.add('left', [8,9, 10, 11],10, true); 
            player.animations.add('right', [4, 5,6 ,7],10, true); 


            stars = game.add.group();
            stars.enableBody = true;
            var star = stars.create(500, 490, 'bird');
             var star = stars.create(700, 490, 'bird');
                     var star = stars.create(200, 490, 'bird');

   

    

            scoreText = game.add.text(16, 16, 'Missing Bird Collected: ', { fontSize: '32px', fill: 'yellow' });
           
            
           niceText = game.add.text(300,350, '', { fontSize: '500px', fill: 'yellow' });
           niceText.fixedToCamera = true;

            messageText = game.add.text(180, 180, '', { fontSize: '120px', fill: 'red' });
            pauseText = game.add.text(300, 350, '', { fontSize: '500px', fill: 'white' });
             game.camera.follow(player, Phaser.Camera.FOLLOW_TOPDOWN);
            pauseText.fixedToCamera = true;
             scoreText.fixedToCamera = true;
              messageText.fixedToCamera = true;
                game.camera.follow(player, Phaser.Camera.FOLLOW_LOCKON);


            
            btn = game.input.keyboard.createCursorKeys();
            btn = game.input.keyboard.createCursorKeys();
  
           
            
        },

update: function() {

    
    game.physics.arcade.collide(player, platforms);





    
           game.physics.arcade.overlap(player, stars, process.collectStar, null, this);
            game.physics.arcade.overlap(player, multo, process.killPlayer, null, this);
        game.physics.arcade.overlap(player, level, process.start, null, this);

  

   
            if (left) {
               
                player.body.velocity.x=-120;
                player.animations.play('left');
            }
            else if (right) {
          
                player.body.velocity.x=120;
                player.animations.play('right');
            } 
            else {
                   player.body.velocity.x=0;

              player.frame = 1;
            }

            if (game.input.currentPointers == 0 && !game.input.activePointer.isMouse){ fire=false; right=false; left=false; duck=false; jump=false;} //this 
        }

}

game.state.add("Level1" ,Level1, false);