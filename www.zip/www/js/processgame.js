var process = function() {
	   "use strict";
        return {
  

 createMultos : function(time) {
    setInterval(function() {
        aswang= multo.create(1300,450, "multo");
        aswang.body.gravity.x = -30;
 

        aswang.body.collideWorldBounds = false;
    },time);
}, 
 createMultos2 : function(time) {
    setInterval(function() {
        aswang2= multo2.create(1300,450, "multo");
        aswang2.body.gravity.x = -30;
 

        aswang2.body.collideWorldBounds = false;
    },time);
}, 
 createMultos3 : function(time) {
    setInterval(function() {
        aswang3= multo3.create(1300,450, "multo");
        aswang3.body.gravity.x = -30;
 

        aswang3.body.collideWorldBounds = false;
    },time);
}, 
 createMultos4 : function(time) {
    setInterval(function() {
        aswang4= multo4.create(1300,450, "multo");
        aswang4.body.gravity.x = -30;
 

        aswang4.body.collideWorldBounds = false;
    },time);
}, 
 createMultos5 : function(time) {
    setInterval(function() {
        aswang5= multo5.create(1300,450, "multo");
        aswang5.body.gravity.x = -30;
 

        aswang5.body.collideWorldBounds = false;
    },time);
}, 

 createMultos6 : function(time) {
    setInterval(function() {
        aswang6= multo6.create(1300,450, "multo");
        aswang6.body.gravity.x = -30;
 

        aswang6.body.collideWorldBounds = false;
    },time);
}, 

 createMultos7 : function(time) {
    setInterval(function() {
        aswang7= multo7.create(1300,450, "multo");
        aswang7.body.gravity.x = -30;
 

        aswang7.body.collideWorldBounds = false;
    },time);
}, 

 createMultos8 : function(time) {
    setInterval(function() {
        aswang8= multo8.create(1300,450, "multo");
        aswang8.body.gravity.x = -30;
 

        aswang8.body.collideWorldBounds = false;
    },time);
}, 
 createMultos9 : function(time) {
    setInterval(function() {
        aswang9= multo9.create(1300,450, "multo");
        aswang9.body.gravity.x = -30;
 

        aswang9.body.collideWorldBounds = false;
    },time);
}, 

createMultos10 : function(time) {
    setInterval(function() {
        aswang10= multo10.create(1300,450, "multo");
        aswang10.body.gravity.x = -80;
 

        aswang10.body.collideWorldBounds = false;
    },time);
}, 





 collectStar : function(player, star) {
    

    star.kill();
    soundeffects.play();
    score += 1; 
    scoreText.text = 'Missing Bird Collected: ' + score+ '';
    setTimeout(function(){
          niceText.text = '';
 
  },1000)
       niceText.text = 'GOOD JOB!';
},
collectStar2 : function(player, star2) {
    

    star2.kill();
    soundeffects.play();
    score += 1; 
    scoreText2.text = 'Missing Bird Collected: ' + score+ '';
    setTimeout(function(){
          niceText.text = '';
 
  },1000)
       niceText.text = 'GOOD JOB!';
},

collectStar3 : function(player, star3) {
    

    star3.kill();
    soundeffects.play();
    score += 1; 
    scoreText.text = 'Missing Bird Collected: ' + score+ '';
    setTimeout(function(){
          niceText.text = '';
 
  },1000)
       niceText.text = 'GOOD JOB!';
},

collectStar4 : function(player, star4) {
    

    star4.kill();
    soundeffects.play();
    score += 1; 
    scoreText.text = 'Missing Bird Collected: ' + score+ '';
    setTimeout(function(){
          niceText.text = '';
 
  },1000)
       niceText.text = 'GOOD JOB!';
},

collectStar5 : function(player, star5) {
    

    star5.kill();
    soundeffects.play();
    score += 1; 
    scoreText.text = 'Missing Bird Collected: ' + score+ '';
    setTimeout(function(){
          niceText.text = '';
 
  },1000)
       niceText.text = 'GOOD JOB!';
},
collectStar6 : function(player, star6) {
    

    star6.kill();
    soundeffects.play();
    score += 1; 
    scoreText.text = 'Missing Bird Collected: ' + score+ '';
    setTimeout(function(){
          niceText.text = '';
 
  },1000)
       niceText.text = 'GOOD JOB!';
},
collectStar7 : function(player, star7) {
    

    star7.kill();
    soundeffects.play();
    score += 1; 
    scoreText.text = 'Missing Bird Collected: ' + score+ '';
    setTimeout(function(){
          niceText.text = '';
 
  },1000)
       niceText.text = 'GOOD JOB!';
},
collectStar8 : function(player, star8) {
    

    star8.kill();
    soundeffects.play();
    score += 1; 
    scoreText.text = 'Missing Bird Collected: ' + score+ '';
    setTimeout(function(){
          niceText.text = '';
 
  },1000)
       niceText.text = 'GOOD JOB!';
},

collectStar9 : function(player, star9) {
    

    star9.kill();
    soundeffects.play();
    score += 1; 
    scoreText.text = 'Missing Bird Collected: ' + score+ '';
    setTimeout(function(){
          niceText.text = '';
 
  },1000)
       niceText.text = 'GOOD JOB!';
},
collectStar10 : function(player, star10) {
    

    star10.kill();
    soundeffects.play();
    score += 1; 
    scoreText.text = 'Missing Bird Collected: ' + score+ '';
    setTimeout(function(){
          niceText.text = '';
 
  },1000)
       niceText.text = 'GOOD JOB!';
},
killPlayer : function(player, multo) {
    game.state.start("Gameover");
    effect.play();

  player.kill();

  
},

killPlayer2 : function(player, multo2) {
  player.kill();
    effect.play();
  game.state.start("Gameover2");
},

killPlayer3 : function(player, multo3) {
  player.kill();
  effect.play();
  game.state.start("Gameover3");
},

killPlayer4 : function(player, multo4) {
  player.kill();
  effect.play();
  game.state.start("Gameover4");
},

killPlayer5 : function(player, multo5) {
  player.kill();
  effect.play();
  game.state.start("Gameover5");
},

killPlayer6 : function(player, multo6) {
  player.kill();
  effect.play();
  game.state.start("Gameover6");
},

killPlayer7 : function(player, multo7) {
  player.kill();
  effect.play();
  game.state.start("Gameover7");
},

killPlayer8 : function(player, multo8) {
  player.kill();
  effect.play();
  game.state.start("Gameover8");
},

killPlayer9 : function(player, multo9) {
  player.kill();
  effect.play();
  game.state.start("Gameover9");
},

killPlayer10 : function(player, multo10) {
  player.kill();
  effect.play();
  game.state.start("Gameover10");
},





 
audio : function(time){
    setInterval(function(){
        bgAudio.play();
        },time)
 

},

start : function(){
    game.state.start("Level2");
    console.log("x");
    },
    
    start1 : function(){
    game.state.start("Level3");
    console.log("x");
    },

      start2 : function(){
    game.state.start("Level4");
    console.log("x");
    },

       start3 : function(){
    game.state.start("Level5");
    console.log("x");
    },

         start4 : function(){
    game.state.start("Level6");
    console.log("x");
    },

          start5 : function(){
    game.state.start("Level7");
    console.log("x");
    },
    
           start6 : function(){
    game.state.start("Level8");
    console.log("x");
    },

             start7 : function(){
    game.state.start("Level9");
    console.log("x");
    },
    
               start8 : function(){
    game.state.start("Level10");
    console.log("x");
    },
              start11 : function(){
    game.state.start("Congrats");
    console.log("x");
    },
    
    restart : function (){
        game.state.start("Level1");
    },
      restart2 : function (){
        game.state.start("Level2");
    },
      restart3 : function (){
        game.state.start("Level3");
    },
      restart4 : function (){
        game.state.start("Level4");
    },
      restart5 : function (){
        game.state.start("Level5");
    },
      restart6 : function (){
        game.state.start("Level6");
    },
      restart7 : function (){
        game.state.start("Level7");
    },
      restart8 : function (){
        game.state.start("Level8");
    },
      restart9 : function (){
        game.state.start("Level9");
    },
      restart10 : function (){
        game.state.start("Level10");
    },

    pause:function(){

    },
    
     pause : function(){
    game.paused = true;
    pauseText.text = 'GAME PAUSED , tap to unpause';
},

    unpause:  function (event){
      
   game.paused = false;
    pauseText.text = '';
},


 jump:  function (){
   player.body.velocity.y = -350;
},


    
}
}();