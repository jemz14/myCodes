var Gameover = {

    preload : function() {
         game.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL;
            game.scale.pageAlignHorizontally = true;
            game.scale.pageAlignVertically = true;
        game.load.image('gameover', 'assets/scary.jpg');
    },

    create : function() {

     
        this.add.button(0, 0, 'gameover', this.startGame, this);

    

    },

    startGame: function () {

        this.state.start('Level1');

    }

};
game.state.add("Gameover" ,Gameover, false);

var Gameover2 = {

    preload : function() {
        game.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL;
            game.scale.pageAlignHorizontally = true;
            game.scale.pageAlignVertically = true;
        game.load.image('gameover', 'assets/scary.jpg');
    },

    create : function() {

        
        this.add.button(0, 0, 'gameover', this.startGame, this);

    

    },

    startGame: function () {

        
        this.state.start('Level2');

    }

};
game.state.add("Gameover2" ,Gameover2, false);

var Gameover3 = {

    preload : function() {
   game.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL;
            game.scale.pageAlignHorizontally = true;
            game.scale.pageAlignVertically = true;
        game.load.image('gameover', 'assets/scary.jpg');
    },

    create : function() {

      
        this.add.button(0, 0, 'gameover', this.startGame, this);

    

    },

    startGame: function () {

     
        this.state.start('Level3');

    }

};
game.state.add("Gameover3" ,Gameover3, false);

var Gameover4 = {

    preload : function() {
        game.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL;
            game.scale.pageAlignHorizontally = true;
            game.scale.pageAlignVertically = true;
        game.load.image('gameover', 'assets/scary.jpg');
    },

    create : function() {

 
        this.add.button(0, 0, 'gameover', this.startGame, this);

    

    },

    startGame: function () {

    
        this.state.start('Level4');

    }

};
game.state.add("Gameover4" ,Gameover4, false);

var Gameover5 = {

    preload : function() {
       game.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL;
            game.scale.pageAlignHorizontally = true;
            game.scale.pageAlignVertically = true;
        game.load.image('gameover', 'assets/scary.jpg');
    },

    create : function() {

        
        this.add.button(0, 0, 'gameover', this.startGame, this);

    

    },

    startGame: function () {

      
        this.state.start('Level5');

    }

};
game.state.add("Gameover5" ,Gameover5, false);

var Gameover6 = {

    preload : function() {
      game.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL;
            game.scale.pageAlignHorizontally = true;
            game.scale.pageAlignVertically = true;
        game.load.image('gameover', 'assets/scary.jpg');
    },

    create : function() {

        this.add.button(0, 0, 'gameover', this.startGame, this);

    

    },

    startGame: function () {

     
        this.state.start('Level6');

    }

};
game.state.add("Gameover6" ,Gameover6, false);

var Gameover7 = {

    preload : function() {
        game.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL;
            game.scale.pageAlignHorizontally = true;
            game.scale.pageAlignVertically = true;
        game.load.image('gameover', 'assets/scary.jpg');
    },

    create : function() {

  
        this.add.button(0, 0, 'gameover', this.startGame, this);

    

    },

    startGame: function () {

        
        this.state.start('Level7');

    }

};
game.state.add("Gameover7" ,Gameover7, false);

var Gameover8 = {

    preload : function() {
       game.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL;
            game.scale.pageAlignHorizontally = true;
            game.scale.pageAlignVertically = true;
        game.load.image('gameover', 'assets/valak.jpg');
    },

    create : function() {


        this.add.button(0, 0, 'gameover', this.startGame, this);

    

    },

    startGame: function () {

     
        this.state.start('Level8');

    }

};
game.state.add("Gameover8" ,Gameover8, false);

var Gameover9 = {

    preload : function() {
       game.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL;
            game.scale.pageAlignHorizontally = true;
            game.scale.pageAlignVertically = true;
        game.load.image('gameover', 'assets/valak.jpg');
    },

    create : function() {

       
        this.add.button(0, 0, 'gameover', this.startGame, this);

    

    },

    startGame: function () {

    
        this.state.start('Level9');

    }

};
game.state.add("Gameover9" ,Gameover9, false);

var Gameover10 = {

    preload : function() {
      game.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL;
            game.scale.pageAlignHorizontally = true;
            game.scale.pageAlignVertically = true;
        game.load.image('gameover', 'assets/valak.jpg');
    },

    create : function() {

      
        this.add.button(0, 0, 'gameover', this.startGame, this);

    

    },

    startGame: function () {

     
        this.state.start('Level10');

    }

};
game.state.add("Gameover10" ,Gameover10, false);

var Congrats = {
           preload : function() {
      game.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL;
            game.scale.pageAlignHorizontally = true;
            game.scale.pageAlignVertically = true;
        game.load.image('grats', 'assets/green.jpeg');
    },

    create : function() {

      
        this.add.button(0, 0, 'grats', this.startGame, this);

    

    },

    startGame: function () {

     
        this.state.start('Menu');

    }
};
game.state.add("Congrats",Congrats,false);